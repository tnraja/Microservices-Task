const express = require('express');
const app = express();
app.get('/', (req, res) => res.json({service: 'product', status: 'ok'}));
app.listen(3001, '0.0.0.0', () => console.log('Product service on 3001'));
