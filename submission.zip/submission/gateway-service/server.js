const express = require('express');
const app = express();
app.get('/', (req, res) => res.json({gateway: 'healthy', services: ['user','product']}));
app.listen(3003, '0.0.0.0', () => console.log('Gateway on 3003'));
